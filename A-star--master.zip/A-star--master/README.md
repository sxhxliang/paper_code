# A-star-
a search algorithm implemented in python3.5 that searches through data to find the shortest path.
the A_star searches using data from the data file.
the data file should be of type csv with single-space delimitters.
the data file should not have any trailling lines or spaces but only thee columns.
the node_map is a temporary file created that can be changed at will by the program .
it is adictionary of dictionaries that provide for a two way search.
both the nodemap and data files should be in the same directory as the a_star.py
